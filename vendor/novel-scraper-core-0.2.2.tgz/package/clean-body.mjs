// Remove observed page furniture; preserve prose and author notes.
const canonical = value => value.normalize('NFKC').toLowerCase().replace(/[\p{P}\p{Z}\s]/gu, '');
const noise = [
  /^小說[：:]\s*[、，,\s]*$/u,
  /^小說相關$/u,
  /^熱門推薦$/u,
  /^_?女生小說就在你最值得收藏的書客居$/u,
  /^如果您發現內容有誤，請您用瀏覽器來訪問[!！]?$/u,
  /^[（(]?看完記得收藏書簽方便下次閱讀[!！]?[）)]?$/u,
  /^27k即將無法訪問，請記住最新網址$/u,
];

export function cleanBody(title, body, options = {}) {
  const { siteNoise = true, endMarker = true, exactLines = [] } = options;
  const removed = [];
  let lines = body.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
  lines = lines.flatMap(line => {
    if ((siteNoise && noise.some(pattern => pattern.test(line))) || exactLines.includes(line)) {
      removed.push({ reason: 'website_text', text: line });
      return [];
    }
    const stripped = endMarker ? line.replace(/[（(]本章完[）)]\s*$/u, '').trim() : line;
    if (stripped !== line) removed.push({ reason: 'end_marker', text: '(本章完)' });
    return stripped ? [stripped] : [];
  });
  const match = title.match(/^第(\d+)章\s*(.*)$/u);
  if (match) {
    const [, n, name] = match;
    const full = canonical(title);
    const short = canonical(name);
    const part = name.match(/[（(](\d+)[）)]$/u)?.[1];
    while (lines.length) {
      const line = lines[0];
      const withoutPrefix = line.replace(new RegExp(`^${n}\\s*[.．]\\s*`), '');
      const duplicate = new RegExp(`^${n}\\s*[.．]$`).test(line)
        || canonical(withoutPrefix) === full
        || canonical(line) === `第${n}章`
        || (part && canonical(line) === `第${n}章${part}`)
        || (short && canonical(withoutPrefix) === short);
      if (!duplicate) break;
      removed.push({ reason: 'duplicate_heading', text: lines.shift() });
    }
  }
  return { body: lines.join('\n\n'), removed };
}
