export interface SiteProfile {
  id: string; name: string; hosts: string[];
  bookTitle: string; chapterLinks: string; chapterTitle: string; chapterBody: string;
  catalogPattern?: string; chapterPattern?: string; minBodyLength?: number;
  transport?: 'http' | 'browser';
}
export interface CrawlOptions { url: string; profileId?: string; cleaning?: 'none' | 'conservative'; exactLines?: string[]; limit?: number | null }
export interface RemovedItem { reason: string; text: string }
export interface CrawlPreview { title: string; total: number; profileId: string; chapterTitle: string; gaps: {before:number;after:number}[]; before: string; after: string; removed: RemovedItem[] }
export interface CrawlStatus {
  id: string; url: string; profileId: string; options: {cleaning:'none'|'conservative';exactLines:string[];limit:number|null};
  title: string; state: 'running'|'interrupted'|'paused'|'failed'|'incomplete'|'sample_complete'|'complete';
  total: number; selected: number; completed: number; failures: {url:string;title:string;error:string}[];
  gaps: {before:number;after:number}[]; updatedAt: string; error?: string;
  rawOutput?: string; cleanedOutput?: string; removedItems?: number;
}
export const builtinProfiles: SiteProfile[];
export function validateProfile(profile: SiteProfile): SiteProfile;
export function parseCatalog(html: string, url: string, profile: SiteProfile): {title:string;chapters:{url:string;title:string}[];gaps:{before:number;after:number}[]};
export function parseChapter(html:string, profile:SiteProfile): {title:string;body:string};
export class ScraperEngine {
  constructor(root:string, options?: {fetchImpl?:typeof fetch;intervalMs?:number;browserLoader?:(url:string, context:{profile:SiteProfile;signal?:AbortSignal;kind:'catalog'|'chapter'})=>Promise<string>});
  profiles(): Promise<SiteProfile[]>;
  saveProfile(profile:SiteProfile): Promise<SiteProfile>;
  preview(options:CrawlOptions, callbacks?:{signal?:AbortSignal}): Promise<CrawlPreview>;
  jobs(): Promise<CrawlStatus[]>;
  recover(id:string): Promise<void>;
  run(options:CrawlOptions, callbacks?:{signal?:AbortSignal;onProgress?:(state:CrawlStatus)=>void}):Promise<CrawlStatus>;
}
