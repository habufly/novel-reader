import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { setTimeout as delay } from 'node:timers/promises';
import { builtinProfiles, validateProfile, validateUrl, parseCatalog, parseChapter } from './profiles.mjs';
import { cleanBody } from '../clean-body.mjs';

export { builtinProfiles, validateProfile, parseCatalog, parseChapter };
const hash = text => createHash('sha256').update(text).digest('hex').slice(0, 24);
const safeName = title => title.replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').slice(0, 100).replace(/[. ]+$/, '') || 'novel';
async function read(file) { return JSON.parse(await fs.readFile(file, 'utf8')); }
async function write(file, data) {
  await fs.mkdir(path.dirname(file), { recursive: true });
  const temp = `${file}.${process.pid}.tmp`;
  await fs.writeFile(temp, typeof data === 'string' ? data : JSON.stringify(data, null, 2), 'utf8');
  await fs.rename(temp, file);
}
function settings(options = {}) {
  const cleaning = options.cleaning ?? 'none';
  if (!['none', 'conservative'].includes(cleaning)) throw new Error('未知清理模式');
  const exactLines = options.exactLines ?? [];
  if (!Array.isArray(exactLines) || exactLines.some(l => typeof l !== 'string' || !l.trim() || /[\r\n]/.test(l))) throw new Error('自訂刪除字句必須是一行一條的完整字句');
  const limit = options.limit ?? null;
  if (limit !== null && (!Number.isInteger(limit) || limit < 1)) throw new Error('章節上限必須是正整數');
  return { cleaning, exactLines, limit };
}
function cleanedRecord(record, profile, options) {
  if (options.cleaning === 'none') return { ...record, removed: [] };
  const result = cleanBody(record.title, record.body, { siteNoise: profile.id === 'zhswx', endMarker: true, exactLines: options.exactLines });
  return { ...record, ...result };
}
function textFile(title, records) {
  return '\ufeff' + title + '\n\n' + records.map(r => `${r.title}\n\n${r.body}`).join('\n\n' + '='.repeat(40) + '\n\n') + '\n';
}

export class ScraperEngine {
  constructor(root, { fetchImpl = globalThis.fetch, intervalMs = 2000, browserLoader } = {}) {
    this.root = path.resolve(root); this.fetchImpl = fetchImpl;
    this.intervalMs = intervalMs; this.active = new Set(); this.lastRequest = 0;
    this.browserLoader = browserLoader;
  }
  async profiles() {
    const profiles = [...builtinProfiles];
    let names = []; try { names = await fs.readdir(path.join(this.root, 'profiles')); } catch (e) { if (e.code !== 'ENOENT') throw e; }
    for (const name of names.filter(n => n.endsWith('.json'))) {
      const p = validateProfile(await read(path.join(this.root, 'profiles', name)));
      const index = profiles.findIndex(v => v.id === p.id);
      if (index < 0) profiles.push(p); else profiles[index] = p;
    }
    return structuredClone(profiles);
  }
  async saveProfile(profile) {
    const valid = validateProfile(profile);
    if (builtinProfiles.some(p => p.id === valid.id)) throw new Error('內建網站設定不可覆寫，請另存為新的 ID');
    await write(path.join(this.root, 'profiles', `${valid.id}.json`), valid);
    return valid;
  }
  async profileFor(url, id) {
    const profiles = await this.profiles();
    const profile = id ? profiles.find(p => p.id === id) : profiles.find(p => p.hosts.includes(new URL(url).hostname));
    if (!profile) throw new Error('此網站尚未設定，請先新增網站設定');
    validateUrl(url, profile); return profile;
  }
  jobId(url, profile) { return hash(`${profile.id}\n${new URL(url).href.split('#')[0]}`); }
  async recover(id) {
    if (!/^[a-f0-9]{24}$/.test(id) || this.active.has(id)) throw new Error('任務仍在執行或 ID 無效');
    const lockPath = path.join(this.root, 'jobs', id, '.lock');
    let pid;
    try { pid = Number(await fs.readFile(lockPath, 'utf8')); } catch (e) { if (e.code === 'ENOENT') return; throw e; }
    if (!Number.isInteger(pid) || pid <= 0) throw new Error('無法判斷鎖定程序，請手動確認');
    try { process.kill(pid, 0); } catch (e) { if (e.code === 'ESRCH') { await fs.unlink(lockPath); return; } throw e; }
    throw new Error('原下載程序仍存在，請先關閉該程序');
  }
  async request(url, profile, signal, kind = 'chapter') {
    validateUrl(url, profile);
    if (profile.transport === 'browser') {
      if (!this.browserLoader) throw Object.assign(new Error('此網站需要一般瀏覽器載入；請使用最新版閱讀器的「網址下載」。CLI 不會自動繞過網站驗證。'), { fatal: true });
      signal?.throwIfAborted();
      const wait = Math.max(0, this.intervalMs - (Date.now() - this.lastRequest));
      if (wait) await delay(wait, undefined, { signal });
      this.lastRequest = Date.now();
      return this.browserLoader(url, { profile: structuredClone(profile), signal, kind });
    }
    for (let attempt = 0; attempt < 4; attempt++) {
      signal?.throwIfAborted();
      const wait = Math.max(0, this.intervalMs - (Date.now() - this.lastRequest));
      if (wait) await delay(wait, undefined, { signal });
      this.lastRequest = Date.now();
      try {
        let target = url;
        let response;
        for (let redirect = 0; redirect <= 5; redirect++) {
          validateUrl(target, profile);
          const timeout = AbortSignal.timeout(30000);
          response = await this.fetchImpl(target, { redirect: 'manual', signal: signal ? AbortSignal.any([signal, timeout]) : timeout, headers: { 'User-Agent': 'NovelScraper/0.2' } });
          if (![301,302,303,307,308].includes(response.status)) break;
          const location = response.headers.get('location');
          if (!location || redirect === 5) throw Object.assign(new Error('重新導向過多或缺少網址'), { fatal: true });
          await response.body?.cancel();
          target = new URL(location, target).href;
        }
        if (!response.ok) {
          const retry = response.headers.get('retry-after');
          const retryMs = retry ? (/^\d+$/.test(retry) ? Number(retry) * 1000 : Math.max(0, Date.parse(retry) - Date.now())) : 0;
          await response.body?.cancel();
          throw Object.assign(new Error(`HTTP ${response.status}`), { fatal: response.status !== 429 && response.status < 500, retryMs });
        }
        const contentType = response.headers.get('content-type') ?? '';
        const encoding = contentType.match(/charset\s*=\s*["']?([^;\s"']+)/i)?.[1];
        const bytes = new Uint8Array(await response.arrayBuffer());
        const prefix = new TextDecoder('latin1').decode(bytes.subarray(0, 4096));
        const charset = encoding ?? prefix.match(/charset\s*=\s*["']?([\w-]+)/i)?.[1] ?? 'utf-8';
        return new TextDecoder(charset).decode(bytes);
      } catch (error) {
        signal?.throwIfAborted();
        if (error.fatal || attempt === 3) throw error;
        await delay(Math.max(error.retryMs || 0, 3000 * 2 ** attempt), undefined, { signal });
      }
    }
  }
  async preview(options, { signal } = {}) {
    const opts = settings(options);
    const profile = await this.profileFor(options.url, options.profileId);
    const catalog = parseCatalog(await this.request(options.url, profile, signal, 'catalog'), options.url, profile);
    const raw = parseChapter(await this.request(catalog.chapters[0].url, profile, signal), profile);
    const cleaned = cleanedRecord(raw, profile, opts);
    return { title: catalog.title, total: catalog.chapters.length, gaps: catalog.gaps, profileId: profile.id, chapterTitle: raw.title, before: raw.body, after: cleaned.body, removed: cleaned.removed };
  }
  async jobs() {
    let names = []; try { names = await fs.readdir(path.join(this.root, 'jobs')); } catch (e) { if (e.code !== 'ENOENT') throw e; }
    const jobs = [];
    for (const id of names.filter(n => /^[a-f0-9]{24}$/.test(n))) {
      try {
        const status = await read(path.join(this.root, 'jobs', id, 'status.json'));
        if (status.state === 'running' && !this.active.has(id)) status.state = 'interrupted';
        jobs.push(status);
      } catch (e) { if (e.code !== 'ENOENT') throw e; }
    }
    return jobs.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  }
  async run(options, { signal, onProgress = () => {} } = {}) {
    const opts = settings(options);
    const profile = await this.profileFor(options.url, options.profileId);
    const url = validateUrl(options.url, profile).href;
    const id = this.jobId(url, profile);
    if (this.active.has(id)) throw new Error('此書正在下載');
    const dir = path.join(this.root, 'jobs', id);
    await fs.mkdir(dir, { recursive: true });
    let lock;
    try { lock = await fs.open(path.join(dir, '.lock'), 'wx'); }
    catch (e) { if (e.code === 'EEXIST') throw new Error('此任務已被鎖定，請確認其他程序是否仍在下載'); throw e; }
    this.active.add(id);
    const state = { id, url, profileId: profile.id, options: opts, title: '', state: 'running', total: 0, selected: 0, completed: 0, failures: [], gaps: [], pid: process.pid };
    const emit = async () => { state.updatedAt = new Date().toISOString(); await write(path.join(dir, 'status.json'), state); try { onProgress(structuredClone(state)); } catch {} };
    const records = [];
    try {
      await lock.writeFile(String(process.pid));
      await emit();
      const html = await this.request(url, profile, signal, 'catalog');
      await write(path.join(dir, 'catalog.html'), html);
      const catalog = parseCatalog(html, url, profile);
      await write(path.join(dir, 'catalog.json'), catalog);
      const selected = catalog.chapters.slice(0, opts.limit ?? undefined);
      Object.assign(state, { title: catalog.title, total: catalog.chapters.length, selected: selected.length, gaps: catalog.gaps });
      await emit();
      for (const chapter of selected) {
        signal?.throwIfAborted();
        const key = hash(chapter.url);
        const recordFile = path.join(dir, 'chapters', `${key}.json`);
        let record;
        try {
          record = await read(recordFile);
          // Reparse saved HTML when the extraction profile changes.
          if (record.url !== chapter.url || record.profileHash !== hash(JSON.stringify(profile)) || !record.body) record = null;
        } catch (e) { if (e.code !== 'ENOENT' && !(e instanceof SyntaxError)) throw e; }
        if (!record) {
          try {
            const chapterHtml = await this.request(chapter.url, profile, signal);
            await write(path.join(dir, 'html', `${key}.html`), chapterHtml);
            record = { url: chapter.url, profileHash: hash(JSON.stringify(profile)), ...parseChapter(chapterHtml, profile) };
            await write(recordFile, record);
          } catch (error) {
            signal?.throwIfAborted();
            state.failures.push({ url: chapter.url, title: chapter.title, error: error.message });
            await emit();
            if (error.fatal) throw error;
            continue;
          }
        }
        records.push(record); state.completed++; await emit();
      }
      state.state = state.failures.length ? 'incomplete' : state.selected < state.total ? 'sample_complete' : 'complete';
    } catch (error) {
      state.state = signal?.aborted ? 'paused' : 'failed'; state.error = error.message;
    } finally {
      try {
        if (state.title && records.length) {
          const partial = state.state !== 'complete' ? '.partial' : '';
          const prefix = path.join(dir, safeName(state.title));
          state.rawOutput = `${prefix}.raw${partial}.txt`;
          await write(state.rawOutput, textFile(state.title, records));
          if (opts.cleaning !== 'none') {
            const cleaned = records.map(r => cleanedRecord(r, profile, opts));
            if (cleaned.some(r => !r.body)) throw new Error('清理後有空白章節，已保留原文但不輸出清理版');
            state.cleanedOutput = `${prefix}.cleaned${partial}.txt`;
            await write(state.cleanedOutput, textFile(state.title, cleaned));
            const changes = cleaned.filter(r => r.removed.length).map(r => ({ url: r.url, title: r.title, removed: r.removed }));
            await write(path.join(dir, 'cleanup-report.json'), changes);
            state.removedItems = changes.reduce((n, c) => n + c.removed.length, 0);
          }
        }
        await emit();
      } catch (error) { state.state = 'failed'; state.error = error.message; await emit(); }
      finally { this.active.delete(id); await lock.close(); await fs.unlink(path.join(dir, '.lock')); }
    }
    return structuredClone(state);
  }
}
