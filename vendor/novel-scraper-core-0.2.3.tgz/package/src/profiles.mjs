import { load } from 'cheerio';

export const builtinProfiles = [{
  id: 'zhswx', name: '宙斯小說網', hosts: ['tw.zhswx.com', 'www.zhswx.com'],
  catalogPattern: '^/chapter/([0-9]+)\\.html$',
  bookTitle: 'h1', chapterLinks: 'td.chapterlist a[href]', chapterTitle: 'h1',
  chapterBody: 'div[style*="text-indent: 2em"][style*="font-size: 20px"]',
  chapterPattern: '^/read/{bookId}_[0-9]+\\.html$',
  minBodyLength: 100,
}, {
  id: 'czbooks', name: '小說狂人', hosts: ['czbooks.net'], transport: 'browser',
  catalogPattern: '^/n/([a-zA-Z0-9_-]+)/?$',
  bookTitle: '.novel-detail h1.title', chapterLinks: '#chapter-list a[href]',
  chapterTitle: '.chapter-detail h1.name', chapterBody: '.chapter-detail .content',
  // Announcements such as 「請假」 are valid, very short catalog entries.
  // Scope and uniqueness of the body selector still distinguish them from challenges.
  chapterPattern: '^/n/{bookId}/[a-zA-Z0-9_-]+/?$', minBodyLength: 1,
}];

// Normalize only site metadata, never the body. Do not remove a mismatching serial.
function titleText(value, profile, chapter = false) {
  let title = value.trim();
  if (profile.id !== 'czbooks') return title;
  if (!chapter) return title.replace(/^《([\s\S]+)》$/, '$1');
  title = title.replace(/^《[^》]+》\s*/, '');
  return title.replace(/^(\d+)[.．]\s*(?=第\1章)/, '');
}

export function validateProfile(profile) {
  if (!profile || !/^[a-z0-9][a-z0-9_-]{0,39}$/.test(profile.id)) throw new Error('網站 ID 只能使用小寫英文、數字、底線與連字號');
  if (!profile.name || !Array.isArray(profile.hosts) || !profile.hosts.length || profile.hosts.some(h => typeof h !== 'string' || !/^[a-z0-9.-]+$/.test(h))) throw new Error('請設定網站名稱與網域');
  for (const key of ['bookTitle', 'chapterLinks', 'chapterTitle', 'chapterBody']) {
    if (typeof profile[key] !== 'string' || !profile[key]) throw new Error(`缺少 CSS 選擇器：${key}`);
    try { load('<main/>')(profile[key]); } catch { throw new Error(`CSS 選擇器無效：${key}`); }
  }
  for (const key of ['catalogPattern', 'chapterPattern']) {
    if (profile[key] !== undefined) {
      if (typeof profile[key] !== 'string' || profile[key].length > 300) throw new Error(`無效設定：${key}`);
      new RegExp(profile[key].replaceAll('{bookId}', '123'));
    }
  }
  const keys = new Set(['id', 'name', 'hosts', 'bookTitle', 'chapterLinks', 'chapterTitle', 'chapterBody', 'catalogPattern', 'chapterPattern', 'minBodyLength', 'transport']);
  for (const key of Object.keys(profile)) if (!keys.has(key)) throw new Error(`不支援的網站設定：${key}`);
  if (profile.minBodyLength !== undefined && (!Number.isInteger(profile.minBodyLength) || profile.minBodyLength < 1)) throw new Error('minBodyLength 必須為正整數');
  if (profile.transport !== undefined && !['http', 'browser'].includes(profile.transport)) throw new Error('transport 必須是 http 或 browser');
  return structuredClone(profile);
}

export function validateUrl(value, profile) {
  let url;
  try { url = new URL(value); } catch { throw Object.assign(new Error('網址無效'), { fatal: true }); }
  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || !profile.hosts.includes(url.hostname)) throw Object.assign(new Error('網址與網站設定不符'), { fatal: true });
  url.hash = '';
  return url;
}

export function parseCatalog(html, catalogUrl, profile) {
  const url = validateUrl(catalogUrl, profile);
  const match = profile.catalogPattern ? url.pathname.match(new RegExp(profile.catalogPattern)) : null;
  if (profile.catalogPattern && !match) throw new Error('目錄網址格式不符合網站設定');
  const $ = load(html);
  const title = titleText($(profile.bookTitle).first().text(), profile);
  if (!title) throw new Error('找不到書名，請檢查網站設定');
  const pattern = profile.chapterPattern ? new RegExp(profile.chapterPattern.replaceAll('{bookId}', match?.[1] ?? '')) : null;
  const seen = new Set(); const chapters = [];
  $(profile.chapterLinks).each((_, element) => {
    const href = $(element).attr('href'); if (!href) return;
    let link; try { link = new URL(href, url); } catch { return; }
    link.hash = '';
    if (link.origin !== url.origin || (pattern && !pattern.test(link.pathname)) || seen.has(link.href)) return;
    const label = titleText($(element).text(), profile, true); if (!label) return;
    seen.add(link.href); chapters.push({ url: link.href, title: label });
  });
  if (!chapters.length) throw new Error('找不到章節連結，請檢查網站設定');
  const gaps = [];
  let previous;
  for (const chapter of chapters) {
    const number = chapter.title.match(/^第(\d+)章/)?.[1];
    const range = profile.id === 'czbooks' ? chapter.title.match(/^(\d+)\s*[~～]\s*(\d+)$/) : null;
    if (!number && !range) continue;
    const after = Number(number ?? range[1]);
    const end = Number(number ?? range[2]);
    if (previous && after !== previous + 1) gaps.push({ before: previous, after });
    previous = end;
  }
  return { title, url: url.href, profileId: profile.id, chapters, gaps };
}

export function parseChapter(html, profile) {
  const $ = load(html);
  const title = titleText($(profile.chapterTitle).first().text(), profile, true);
  const container = $(profile.chapterBody);
  if (container.length !== 1 || !title) throw new Error('找不到唯一正文區或章節標題，請檢查網站設定');
  // Only structural extraction here; content cleanup is a separate, opt-in stage.
  container.find('script, style, noscript').remove();
  let body = '';
  const blocks = new Set(['p', 'div', 'section', 'article', 'li', 'blockquote', 'h1', 'h2', 'h3']);
  function walk(node) {
    if (node.type === 'text') { body += node.data; return; }
    if (node.name === 'br') { body += '\n'; return; }
    if (blocks.has(node.name)) body += '\n';
    for (const child of node.children ?? []) walk(child);
    if (blocks.has(node.name)) body += '\n';
  }
  walk(container[0]);
  body = body.split(/\r?\n/).map(s => s.trim()).filter(Boolean).join('\n\n');
  if (body.length < (profile.minBodyLength ?? 100)) throw new Error('正文過短，可能是錯誤頁面或擷取設定不正確');
  return { title, body };
}
