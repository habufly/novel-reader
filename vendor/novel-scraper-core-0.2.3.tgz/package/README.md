# 小說 TXT 下載工具

## 新版：可擴充核心與閱讀器介面

新版入口是 `cli.mjs` 與 `src/index.mjs`，需要 Node.js 22 以上，先執行 `npm install`。原本的 `download.mjs` / `merge.mjs` 保留供既有那本小說使用；下列新版功能不會覆寫舊 `output/` 或修改已完成的 TXT。

```powershell
node cli.mjs profiles
node cli.mjs preview https://tw.zhswx.com/chapter/65891.html
node cli.mjs download https://tw.zhswx.com/chapter/65891.html --limit=2
node cli.mjs download https://tw.zhswx.com/chapter/65891.html --cleaning=conservative
node cli.mjs jobs
npm test
```

新版支援：

- 依網域選擇網站設定；內建宙斯小說網與小說狂人，書號不再寫死。可自行新增其他靜態網站設定。
- 每本書依網站 ID 與目錄網址分開保存任務，斷點續傳、失敗重試、暫停及目錄跳號回報。
- 保存抓取的 HTML 與抽出的正文。預設 `cleaning=none`，不刪正文文字；主動選擇 `conservative` 才另外輸出清理版與 `cleanup-report.json`。
- 清理版僅使用章首重複標題、已知站點固定提示及「本章完」規則，不使用閱讀器的作者留言／浮水印推測。API 與介面可輸入 `exactLines` 整行匹配規則。
- `src/index.d.ts` 提供 Electron／TypeScript 可使用的型別；核心以獨立套件接入 `C:/My Projects/novel-reader` 的「網址下載」介面，下載後由使用者選擇匯入原文或清理版。

CLI 資料預設位於 `data/jobs/<任務ID>/`，網站設定在 `data/profiles/`，可用 `--data=其他資料目錄` 改變根目錄。閱讀器資料位於 `%APPDATA%/novel-reader/downloads/`，與 CLI 及舊 `output/` 各自獨立。CLI 按 Ctrl+C 暫停；意外中止遺留的鎖可經 API `recover(id)` 或閱讀器「續傳全書」確認舊程序已結束後解除。

### 新增網站

建立 JSON 後執行 `node cli.mjs add-profile my-site.json`，或在閱讀器的「新增網站設定」編輯。CSS 選擇器必須符合目標頁面，正文需恰好匹配一個區域。

```json
{
  "id": "my-site",
  "name": "我的網站",
  "hosts": ["example.com"],
  "bookTitle": "h1",
  "chapterLinks": ".chapter-list a[href]",
  "chapterTitle": "h1",
  "chapterBody": "#content",
  "minBodyLength": 100
}
```

此為格式範例，不是已驗證的網站。可選 `catalogPattern` 驗證目錄路徑、`chapterPattern` 過濾章節路徑；目錄樣式第一個擷取群組可透過 `{bookId}` 放入章節樣式。章節順序保留目錄順序，重複網址去重，外站章節連結排除。

小說狂人設為 `transport: "browser"`，須使用閱讀器內的隔離瀏覽器載入（CLI 沒有瀏覽器時會明確報錯）。遇到 Cloudflare 可由使用者在網站視窗完成驗證；不自動解驗證、不讀取 Chrome Cookie。正文可讀後才會存檔，驗證頁不會當成章節。網站書名與章名的固定前綴只在標題欄位正規化，原始正文仍保留；目錄公告不視為補章，章號跳號仍會回報。

其他登入流程、驗證碼自動化、目錄分頁與章節分頁尚未支援。新版補章介面與舊 `catchup/` 尚未連接；既有 1064 補章仍保留在舊版完整 TXT，不會被這次修改覆寫。原始正文的「保留」指擷取到的文字；HTML 排版、腳本、空白與段落會轉成 TXT 格式。

## 舊版固定書籍工具

針對 https://tw.zhswx.com/chapter/65891.html 的目錄與正文結構製作。需要 Node.js 20 以上，不需安裝額外套件。

```powershell
node .\download.mjs --limit=1  # 試抓第一章
node .\download.mjs            # 下載全書，或接續先前進度
Get-Content .\output\status.json -Encoding utf8
node .\merge.mjs               # 離線重新合併快取與 catchup 補章
```

每次請求間隔至少 2 秒，依目錄順序下載，不依網址 ID 排序。章節快取位於 `output/chapters/`，失敗可重新執行續傳；401/403 會停止。下載完成後才產生正式 TXT；試抓或有缺章時產生 `.partial.txt`。UTF-8 BOM 編碼可供 Windows 記事本開啟。

進度在 `output/status.json`；目錄原始章節清單在 `output/catalog.json`。`completed` 是本次範圍內成功或已快取的章數；`complete` 表示目錄列出的章節皆已下載，不能保證網站目錄本身沒有缺章。目錄可能跳號，程式保留原始標題與順序。

按 Ctrl+C 可停止，章節快取仍保留。意外中止後，確認下載程序已停止，再刪除 `output/.download.lock` 即可重新執行。請只下載有權取得的內容並遵守網站規範。

## 補章

將 UTF-8 的補章 TXT 放入 `catchup/`，第一個非空白行需為 `第1064章 …` 形式的標題，之後為正文。執行 `node .\merge.mjs` 可在不連網的情況下，將補章插入相鄰章節之間並重建正式 TXT；全書下載完成時也會自動套用補章。原始補章檔保留不變。章號重複或找不到前後相鄰章節時會報錯，避免誤插或重複。`status.json` 的 `mergedChapters` 包含補章，`completed` 保留網站下載章數。

合併時會自動清理章首重複章號／標題，以及已辨識的網站提示、宣傳文字與「本章完」標記。故事內容與作者附言保留。清理規則在 `clean-body.mjs`，逐章刪除紀錄在 `output/cleanup-report.json`；章節原始快取及 `catchup/` 檔案不變。
